package com.example.srm;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Register extends AppCompatActivity {

    EditText fullName,email,password,phone;
    Button register;
    TextView login,login2;
    FirebaseAuth fAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        fullName=findViewById(R.id.et1);
        email=findViewById(R.id.et2);
        password=findViewById(R.id.et3);
        phone=findViewById(R.id.et4);
        register=findViewById(R.id.b1);
        login=findViewById(R.id.b1);

        fAuth=FirebaseAuth.getInstance();

        if (fAuth.getCurrentUser()!=null)
        {
            startActivity(new Intent(getApplicationContext(),Home.class));
            finish();
        }

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String et2=email.getText().toString().trim();
                String et3=password.getText().toString().trim();

                if (TextUtils.isEmpty(et2))
                {
                    email.setError("Email is Required");
                }
                if (TextUtils.isEmpty(et3))
                {
                    password.setError("Password is Required");
                    return;
                }
                if (password.length()<6)
                {
                    password.setError("Password must be >= 6 Character");
                    return;
                }
                fAuth.createUserWithEmailAndPassword(et2,et3).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful())
                        {
                            Toast.makeText(Register.this, "User Account Created",Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(),Home.class));
                        }
                        else
                        {
                            Toast.makeText(Register.this, "An Error!...."+task.getException().getMessage(),Toast.LENGTH_SHORT).show();

                        }
                    }
                });

            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(getApplicationContext(),Home.class));
            }
        });
    }
}